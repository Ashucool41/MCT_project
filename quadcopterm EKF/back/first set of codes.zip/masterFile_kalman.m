%master file for kalman filter
clear all
close all
csvread('Sorted_time_wise.csv')
home =[]; %first gps lat lon and alt

