function [Xkp] = predictFunc(Xk,U,Ap,B)
subs(Ap,Xk,A);
end